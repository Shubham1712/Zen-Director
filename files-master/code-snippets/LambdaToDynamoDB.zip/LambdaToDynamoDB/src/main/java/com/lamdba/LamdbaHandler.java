package com.lamdba;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;

public class LamdbaHandler implements RequestHandler<SQSEvent, Void>{

	@Override
	public Void handleRequest(SQSEvent event, Context context) {

		Properties prop = new Properties();
		 InputStream input = null;
		try {
			input = new FileInputStream("config/application.properties");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		 try {
			prop.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
		 
		String msgId = event.getRecords().get(0).getMessageId();
		String msg = event.getRecords().get(0).getBody();
		
		System.out.println("Message Id - "+msgId+"   MessageBody - "+msg);
		msg = possibleCombinations(msg);
		Map<String, AttributeValue> item = newItem(msgId, msg);
		
		String tableName = prop.getProperty("tableName");
		String amazonAWSAccessKey = prop.getProperty("amazonAWSAccessKey");
		String amazonAWSSecretKey = prop.getProperty("amazonAWSSecretKey");

		// AWS DB client
		AmazonDynamoDB dbClient = AmazonDynamoDBClientBuilder.standard()
				  			.withRegion(Regions.US_EAST_1)
				  			.withCredentials(new  AWSStaticCredentialsProvider(new BasicAWSCredentials(amazonAWSAccessKey, amazonAWSSecretKey))) 
				  			.build();
		 
		PutItemRequest putItemRequest = new PutItemRequest(tableName, item);
		PutItemResult putItemResult = dbClient.putItem(putItemRequest);
		
		System.out.println("Message "+msg);
		System.out.println("\nResult : " + putItemResult.getSdkHttpMetadata().getHttpStatusCode());
		
		return null;
	}

	private String possibleCombinations(String msg) {
		
		String[] input = msg.split(",");
		int inputLength = input.length;
        int concatLength = (inputLength * inputLength);
        String[] concat = new String[concatLength];
        for (int i = 0; i < inputLength; i++) {
            concat[i] = input[i];
        }
        String x, y;
        int count = inputLength;
        for (int i = 0; i < inputLength; i++) {
            for (int j = 0; j < inputLength; j++) {
                x = input[i] + input[j];
                y = input[i] + input[i];

 

                if (x.equals(y)) {
                    // System.out.println("Value of x : "+x+"\nValue of y : "+y);
                } else {
                    concat[count] = x;
                    count++;
                }
            }
        }
        
        return Arrays.toString(concat);
	}

	private Map<String, AttributeValue> newItem(String msgId, String msg) {
		Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
		item.put("msgId", new AttributeValue(msgId));
		item.put("message", new AttributeValue(msg));

		return item;
	}


	
}
