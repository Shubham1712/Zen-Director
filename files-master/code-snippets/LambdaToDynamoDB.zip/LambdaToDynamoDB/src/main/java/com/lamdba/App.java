package com.lamdba;

import java.io.FileNotFoundException;
import java.util.Arrays;

public class App {

	public static void main(String[] args) throws FileNotFoundException {

		 String[] input = { "A", "B", "C", "D" };
	        int inputLength = input.length;
	        int concatLength = (inputLength * inputLength);
	        String[] concat = new String[concatLength];
	        for (int i = 0; i < inputLength; i++) {
	            concat[i] = input[i];
	        }
	        String x, y;
	        int count = inputLength;
	        for (int i = 0; i < inputLength; i++) {
	            for (int j = 0; j < inputLength; j++) {
	                x = input[i] + input[j];
	                y = input[i] + input[i];

	 

	                if (x.equals(y)) {
	                    // System.out.println("Value of x : "+x+"\nValue of y : "+y);
	                } else {
	                    concat[count] = x;
	                    count++;
	                }
	            }
	        }

	 

	        System.out.println("The Length of input String Array is : " + inputLength + "\n");
	        System.out.println("The input String Array is :");
	        for (int i = 0; i < inputLength; i++) {
	            System.out.println(input[i]);
	        }

	 

	        System.out.println("The Length of concat String Array is : " + concatLength + "\n");
	        System.out.println("The Concatinated String Array is :");
	        for (int i = 0; i < concatLength; i++) {
	            System.out.println(concat[i]);
	        }
	        
	        System.out.println(Arrays.toString(concat));
	    }
	
	
	
	 

}
