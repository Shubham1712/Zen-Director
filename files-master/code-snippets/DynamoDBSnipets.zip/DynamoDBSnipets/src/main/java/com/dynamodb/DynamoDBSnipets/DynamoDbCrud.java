package com.dynamodb.DynamoDBSnipets;

import java.util.HashMap;
import java.util.Map;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.AttributeValueUpdate;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.DeleteItemRequest;
import com.amazonaws.services.dynamodbv2.model.DeleteItemResult;
import com.amazonaws.services.dynamodbv2.model.GetItemRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.model.QueryRequest;
import com.amazonaws.services.dynamodbv2.model.QueryResult;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.model.UpdateItemRequest;
import com.amazonaws.services.dynamodbv2.model.UpdateItemResult;
import com.amazonaws.services.dynamodbv2.util.TableUtils;

public class DynamoDbCrud {

	
	 // Local DB Client 
	static AmazonDynamoDB dbClient =  AmazonDynamoDBClientBuilder.standard() 
			.withEndpointConfiguration(new  AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "us-west-2"))
			.build();
	 

	// AWS DB client
	/*
	 * static AWSCredentials credentials = new
	 * ProfileCredentialsProvider("default").getCredentials();
	 * static AmazonDynamoDB dbClient = AmazonDynamoDBClientBuilder.standard()
	 * .withRegion(Regions.US_WEST_2) .withCredentials(new
	 * AWSStaticCredentialsProvider(credentials)) .build();
	 */

	public static void main(String[] args) {

		String tableName = "Employee";

		// if(dbClient.describeTable(tableName).getTable().getTableStatus().
		// equalsIgnoreCase("ACTIVE")) { dbClient.deleteTable(tableName); }

		CreateTableRequest createTableRequest = new CreateTableRequest().withTableName(tableName)
				.withKeySchema(new KeySchemaElement().withAttributeName("Id").withKeyType(KeyType.HASH))
				.withAttributeDefinitions(
						new AttributeDefinition().withAttributeName("Id").withAttributeType(ScalarAttributeType.N))
				.withProvisionedThroughput(
						new ProvisionedThroughput().withReadCapacityUnits(1L).withWriteCapacityUnits(1L));

		// Creating Table
		// dbClient.createTable(createTableRequest);
		TableUtils.createTableIfNotExists(dbClient, createTableRequest);

		TableDescription description = dbClient.describeTable(tableName).getTable();
		System.out.println("Table Description : \nTableID : " + description.getTableId() + "\nTableName : "
				+ description.getTableName() + "\nTableArn : " + description.getTableArn() + "\nTableStatus : "
				+ description.getTableStatus() + "\nTableCreatedDate : " + description.getCreationDateTime());

		testCRUDOperations(tableName);

		// dbClient.deleteTable(tableName);
		// System.out.println("Table deleted Successfully \n");
		System.out.println("Example complete!");
	}

	private static void testCRUDOperations(String tableName) {

		Map<String, AttributeValue> item = newItem(1, "Shubham", "Pune");
		Map<String, AttributeValue> item1 = newItem(2, "Anuj", "Nasik");
		HashMap<String, AttributeValue> key_to_get = new HashMap<String, AttributeValue>();
		Map<String, AttributeValue> retrievedItem = null;
		Map<String, AttributeValueUpdate> updateItem = null;

		// save Item
		PutItemRequest putItemRequest = new PutItemRequest(tableName, item);
		PutItemResult putItemResult = dbClient.putItem(putItemRequest);
		dbClient.putItem(tableName, item1); // Use batchwriteitem here
		// PutItemResult putItemResult = dbClient.putItem(tableName, item);

		System.out.println("\nResult : " + putItemResult.getSdkHttpMetadata().getHttpStatusCode());

		// Get Item
		key_to_get.put("Id", new AttributeValue().withN(Integer.toString(1)));
		Map<String, String> expressionAttributeNames = new HashMap<String, String>();
		expressionAttributeNames.put("#N", "name");
		
		
		System.out.println(key_to_get);
		GetItemRequest getItemRequest = new GetItemRequest().withKey(key_to_get).withTableName(tableName)
				.withProjectionExpression("Id,#N").withExpressionAttributeNames(expressionAttributeNames);
		retrievedItem = dbClient.getItem(getItemRequest).getItem();

		// GetItemResult getItemResult = dbClient.getItem(tableName, key_to_get);
		System.out.println("\nRetrieved Item : " + retrievedItem);

		// Update Item
		updateItem = updateItem("Rahul", "Mumbai");
		UpdateItemRequest updateItemRequest = new UpdateItemRequest(tableName, key_to_get, updateItem);
		UpdateItemResult updateItemResult = dbClient.updateItem(updateItemRequest);

		// UpdateItemResult updateItemResult = dbClient.updateItem(tableName,
		// key_to_get, updateItem);
		System.out.println("\nUpdated Item Status : " + updateItemResult.getSdkHttpMetadata().getHttpStatusCode());

		// Update add new Attribute(Column)
		Map<String, AttributeValue> expressionAttributeValues = new HashMap<String, AttributeValue>();
		expressionAttributeValues.put(":val1", new AttributeValue().withS("Software Engineer"));

		ReturnValue returnValues = ReturnValue.ALL_NEW;

		UpdateItemRequest updateItemRequest1 = new UpdateItemRequest().withTableName(tableName).withKey(key_to_get)
				.withUpdateExpression("set Post = :val1").withExpressionAttributeValues(expressionAttributeValues)
				.withReturnValues(returnValues);

		UpdateItemResult result = dbClient.updateItem(updateItemRequest1);
		// Check the response.
		System.out.println("\nPrinting item after adding new attribute - " + result.getAttributes());

		// Update Existing Attribute Conditionally
		Map<String, AttributeValue> expressionAttributeValues1 = new HashMap<String, AttributeValue>();
		expressionAttributeValues1.put(":a", new AttributeValue().withS("Rahul"));
		expressionAttributeValues1.put(":b", new AttributeValue().withS("Nikhil"));

		ReturnValue returnValue = ReturnValue.ALL_NEW;

		UpdateItemRequest updateItemRequest2 = new UpdateItemRequest().withTableName(tableName).withKey(key_to_get)
				.withUpdateExpression("set #N = :b").withConditionExpression("#N = :a")
				.withExpressionAttributeValues(expressionAttributeValues1)
				.withExpressionAttributeNames(expressionAttributeNames).withReturnValues(returnValue);

		UpdateItemResult updateItemResult2 = dbClient.updateItem(updateItemRequest2);
		System.out.println("\nUpdating Attribute value Conditional Exp : " + updateItemResult2.getAttributes());

		// Scan operation
		Map<String, AttributeValue> expressionAttributeValues3 = new HashMap<String, AttributeValue>();
		expressionAttributeValues3.put(":val", new AttributeValue().withN("1"));

		ScanRequest scanRequest = new ScanRequest().withTableName(tableName).withFilterExpression("Id > :val")
				.withExpressionAttributeValues(expressionAttributeValues3);

		ScanResult scanResult = dbClient.scan(scanRequest);
		System.out.println("\nScan operation : ");
		for (Map<String, AttributeValue> iteMap : scanResult.getItems()) {
			System.out.println(iteMap);
		}

		// Query operation
		QueryRequest queryRequest = new QueryRequest().withKeyConditionExpression("Id = :val")
				.withExpressionAttributeValues(expressionAttributeValues3).withTableName(tableName);

		QueryResult items = dbClient.query(queryRequest);

		System.out.println("\nQuery operation : ");
		for (Map<String, AttributeValue> iteMap : items.getItems()) {
			System.out.println(iteMap);
		}

		// Delete Item
		DeleteItemRequest deleteItemRequest = new DeleteItemRequest().withKey(key_to_get).withTableName(tableName);
		DeleteItemResult deleteItemResult = dbClient.deleteItem(deleteItemRequest);

		// DeleteItemResult deleteItemResult = dbClient.deleteItem(tableName,
		// key_to_get);
		System.out.println("\nItem deleted : " + deleteItemRequest);

	}

	private static Map<String, AttributeValue> newItem(int id, String name, String city) {
		Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
		item.put("Id", new AttributeValue().withN(Integer.toString(id)));
		item.put("name", new AttributeValue(name));
		item.put("city", new AttributeValue(city));

		return item;
	}

	private static Map<String, AttributeValueUpdate> updateItem(String name, String city) {
		Map<String, AttributeValueUpdate> item = new HashMap<String, AttributeValueUpdate>();
		item.put("name", new AttributeValueUpdate().withValue(new AttributeValue(name)));
		item.put("city", new AttributeValueUpdate().withValue(new AttributeValue(city)));

		return item;
	}
}
