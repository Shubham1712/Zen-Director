package com.serializeobject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.serializeobject.Employee;

public class EmployeeTest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		List<Employee> objectList = new ArrayList<Employee>();
		objectList.add(new Employee("Shubham", 24, "Pune"));
		objectList.add(new Employee("Rahul", 25, "Mumbai"));
		objectList.add(new Employee("Sharad", 30, "Nagpur"));
		
		//Employee e = new Employee("Sharad", 26, "Nagpur");
		
		byte[] serializedObject = serialize(objectList);
		
		int sumAge = deserialize(serializedObject);
		System.out.println("Sum of ages is : "+sumAge);
		
	}
	
	private static byte[] serialize(List<Employee> objectList) throws IOException {

		ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(baos);
		objectOutputStream.writeObject(objectList);
		objectOutputStream.flush();
		
		
		return baos.toByteArray();
	}

	private static int deserialize(byte[] serializedObject) throws IOException, ClassNotFoundException {

		ByteArrayInputStream bais = new ByteArrayInputStream(serializedObject);
		ObjectInputStream ois = new ObjectInputStream(bais);
		
		List<Employee> listObj = null;
		Employee emp = null;
		int sum = 0;
		
		listObj =   (List<Employee>) ois.readObject();
		//System.out.println("List Size = "+listObj.toString());
		
		
		  for(int i=0; i < listObj.size(); i++) { 
			  	
			  emp = listObj.get(i);
			  sum = sum + emp.getAge(); 
		}
		 
		 
		return sum;
	}
	
}

