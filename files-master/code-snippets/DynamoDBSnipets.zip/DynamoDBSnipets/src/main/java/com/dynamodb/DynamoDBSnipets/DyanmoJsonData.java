package com.dynamodb.DynamoDBSnipets;

import java.util.HashMap;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.GetItemRequest;
import com.amazonaws.services.dynamodbv2.model.GetItemResult;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.util.TableUtils;

import reactor.core.publisher.Mono;

public class DyanmoJsonData {
	
	
	// AWS DB client
		  static AWSCredentials credentials = new ProfileCredentialsProvider("default").getCredentials();
		  static AmazonDynamoDB dbClient = AmazonDynamoDBClientBuilder.standard()
		  .withRegion(Regions.US_EAST_1).withCredentials(new
		  AWSStaticCredentialsProvider(credentials)) 
		  .build();
		 
		  
		  public static void main(String[] args) {

				String tableName = "Employee";

				// if(dbClient.describeTable(tableName).getTable().getTableStatus().
				// equalsIgnoreCase("ACTIVE")) { dbClient.deleteTable(tableName); }

				CreateTableRequest createTableRequest = new CreateTableRequest().withTableName(tableName)
						.withKeySchema(new KeySchemaElement().withAttributeName("Id").withKeyType(KeyType.HASH))
						.withAttributeDefinitions(
								new AttributeDefinition().withAttributeName("Id").withAttributeType(ScalarAttributeType.N))
						.withProvisionedThroughput(
								new ProvisionedThroughput().withReadCapacityUnits(1L).withWriteCapacityUnits(1L));

				// Creating Table
				// dbClient.createTable(createTableRequest);
				TableUtils.createTableIfNotExists(dbClient, createTableRequest);

				Mono<ParkingSpace> mono = testCRUDOperations(tableName);
				System.out.println(mono);
				// dbClient.deleteTable(tableName);
				// System.out.println("Table deleted Successfully \n");
				System.out.println("Example complete!");
			}

			private static Mono<ParkingSpace> testCRUDOperations(String tableName) {
				
				HashMap<String, AttributeValue> key_to_get = new HashMap<String, AttributeValue>();
				key_to_get.put("id", new AttributeValue().withN(Integer.toString(1)));
				
				GetItemRequest getItemRequest = new GetItemRequest().withKey(key_to_get).withTableName(tableName);
				GetItemResult retrievedItem = dbClient.getItem(getItemRequest);
			
				return Mono.fromFuture(dbClient.getItem(getItemRequest)).map(GetItemRequest::item).map(map -> map.get("id").n())
		                .map(json -> {
		                    try {
		                        return objectMapper.readValue(json, ParkingSpace.class);
		                    } catch (IOException e) {
		                        LOGGER.error("Failed to convert json to object", e);
		                        throw new RuntimeException(e);
		                    }
		                }).onErrorResume(error -> {

		                    return Mono.empty();
		                });
				
				
				
			}
}
