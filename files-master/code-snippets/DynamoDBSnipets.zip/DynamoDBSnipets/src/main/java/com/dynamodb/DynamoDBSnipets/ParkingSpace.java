package com.dynamodb.DynamoDBSnipets;

import java.util.Date;

public class ParkingSpace {

	Long price;
	Date availableDate;
	String carParkType;
	String parkingType;
	int capacity;
	boolean available;
	
	
	
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public Date getAvailableDate() {
		return availableDate;
	}
	public void setAvailableDate(Date availableDate) {
		this.availableDate = availableDate;
	}
	public String getCarParkType() {
		return carParkType;
	}
	public void setCarParkType(String carParkType) {
		this.carParkType = carParkType;
	}
	public String getParkingType() {
		return parkingType;
	}
	public void setParkingType(String parkingType) {
		this.parkingType = parkingType;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public boolean isAvailable() {
		return available;
	}
	public void setAvailable(boolean available) {
		this.available = available;
	}
	@Override
	public String toString() {
		return "ParkingSpace [price=" + price + ", availableDate=" + availableDate + ", carParkType=" + carParkType
				+ ", parkingType=" + parkingType + ", capacity=" + capacity + ", available=" + available + "]";
	}
	
	
}
