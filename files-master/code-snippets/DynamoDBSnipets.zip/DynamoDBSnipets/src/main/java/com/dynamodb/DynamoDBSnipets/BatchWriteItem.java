package com.dynamodb.DynamoDBSnipets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.BatchWriteItemRequest;
import com.amazonaws.services.dynamodbv2.model.BatchWriteItemResult;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.PutRequest;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.util.TableUtils;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;

public class BatchWriteItem {

			static AmazonDynamoDB dbClient = AmazonDynamoDBClientBuilder.standard()
					.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "us-west-2"))
					.build();
			
			
			public static void main(String[] args) {
					
		    	String tableName = "Emp";
		    	
				 // if(dbClient.describeTable(tableName).getTable().getTableStatus().
				// equalsIgnoreCase("ACTIVE")) { dbClient.deleteTable(tableName); }
				 
		    	
		    	CreateTableRequest createTableRequest = new CreateTableRequest()
		    			.withTableName(tableName).withKeySchema(new KeySchemaElement().withAttributeName("Id").withKeyType(KeyType.HASH))
		    			.withAttributeDefinitions(new AttributeDefinition().withAttributeName("Id")
		    			.withAttributeType(ScalarAttributeType.N))
		    			.withProvisionedThroughput(new ProvisionedThroughput().withReadCapacityUnits(1L).withWriteCapacityUnits(1L));	
		    	
		    	//Creating Table
		    	//dbClient.createTable(createTableRequest);
		    	TableUtils.createTableIfNotExists(dbClient, createTableRequest);
		    	
		    	
		    	TableDescription description = dbClient.describeTable(tableName).getTable();
		    	System.out.println("Table Description : \nTableID : "+description.getTableId()+"\nTableName : "+description.getTableName()
		    						+"\nTableArn : "+description.getTableArn()+"\nTableStatus : "+description.getTableStatus()+
		    						"\nTableCreatedDate : "+description.getCreationDateTime());
		    	
		        testCRUDOperations(tableName);
		        
		        //dbClient.deleteTable(tableName);
		        System.out.println("Table deleted Successfully \n");
		        System.out.println("Example complete!");
			}

			private static void testCRUDOperations(String tableName) {
					
				Map<String, AttributeValue> forum = newItem(1,"Shubham", "Pune");
				Map<String, AttributeValue> forum1 = newItem(2,"Anuj", "Nasik");
				
				Map<String, List<WriteRequest>> requestItems = new HashMap<String, List<WriteRequest>>();
				
				 List<WriteRequest> forumList = new ArrayList<WriteRequest>();
				 forumList.add(new WriteRequest().withPutRequest(new PutRequest().withItem(forum)));
				 forumList.add(new WriteRequest().withPutRequest(new PutRequest().withItem(forum1)));
				 
				 
				 requestItems.put(tableName, forumList);
				 
				 BatchWriteItemRequest batchWriteItemRequest = new BatchWriteItemRequest(requestItems);
				 
				 BatchWriteItemResult batchWriteItemResult = dbClient.batchWriteItem(batchWriteItemRequest);
				 
				 System.out.println("Result : "+batchWriteItemResult.getSdkHttpMetadata().getHttpStatusCode());
				 
				 
				 List<String> attributesToGet = new ArrayList<String>();
				 attributesToGet.add("name");
				 attributesToGet.add("city");
				 ScanResult scanResult = dbClient.scan(tableName, attributesToGet);
				 
				 System.out.println("Scan Result : "+scanResult.getItems());
				
				
	}
			
			private static Map<String, AttributeValue> newItem(int id, String name, String city) {
				Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
				item.put("Id", new AttributeValue().withN(Integer.toString(id)));
				item.put("name", new AttributeValue(name));
				item.put("city", new AttributeValue(city));
				
				return item;
			}
}
