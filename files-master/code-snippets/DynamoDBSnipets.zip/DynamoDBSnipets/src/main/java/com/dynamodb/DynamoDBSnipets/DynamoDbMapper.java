package com.dynamodb.DynamoDBSnipets;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.util.TableUtils;

public class DynamoDbMapper {

	 //Crud operations with local dynamo DB
	/*
	 * static AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
	 * .withEndpointConfiguration(new
	 * AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "us-west-2"))
	 * .build();
	 */
	
	// AWS DB Client
	static AWSCredentials credentials = new  ProfileCredentialsProvider("default").getCredentials();
	static AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
			  .withRegion(Regions.US_WEST_2)
			  .withCredentials(new AWSStaticCredentialsProvider(credentials)) 
			  .build();
	

	    public static void main(String[] args) throws IOException {
	    	
	    	String tableName = "ProductCatalog";
	    	
	    	
	    	CreateTableRequest createTableRequest = new CreateTableRequest()
	    			.withTableName(tableName).withKeySchema(new KeySchemaElement().withAttributeName("Id").withKeyType(KeyType.HASH))
	    			.withAttributeDefinitions(new AttributeDefinition().withAttributeName("Id")
	    			.withAttributeType(ScalarAttributeType.N))
	    			.withProvisionedThroughput(new ProvisionedThroughput().withReadCapacityUnits(1L).withWriteCapacityUnits(1L));	
	    	
	    	TableUtils.createTableIfNotExists(client, createTableRequest);
	    	
	    	TableDescription description = client.describeTable(tableName).getTable();
	    	System.out.println("Table Description : \nTableID : "+description.getTableId()+"\nTableName : "+description.getTableName()
	    						+"\nTableArn : "+description.getTableArn()+"\nTableStatus : "+description.getTableStatus()+
	    						"\nTableCreatedDate : "+description.getCreationDateTime());
	    	
	        testCRUDOperations();
	        System.out.println("Example complete!");
	    }

	    @DynamoDBTable(tableName = "ProductCatalog")
	    public static class CatalogItem {
	        private Integer id;
	        private String title;
	        private String ISBN;
	        private Set<String> bookAuthors;

	        // Partition key
	        @DynamoDBHashKey(attributeName = "Id")
	        public Integer getId() {
	            return id;
	        }

	        public void setId(Integer id) {
	            this.id = id;
	        }

	        @DynamoDBAttribute(attributeName = "Title")
	        public String getTitle() {
	            return title;
	        }

	        public void setTitle(String title) {
	            this.title = title;
	        }

	        @DynamoDBAttribute(attributeName = "ISBN")
	        public String getISBN() {
	            return ISBN;
	        }

	        public void setISBN(String ISBN) {
	            this.ISBN = ISBN;
	        }

	        @DynamoDBAttribute(attributeName = "Authors")
	        public Set<String> getBookAuthors() {
	            return bookAuthors;
	        }

	        public void setBookAuthors(Set<String> bookAuthors) {
	            this.bookAuthors = bookAuthors;
	        }

	        @Override
	        public String toString() {
	            return "Book [ISBN=" + ISBN + ", bookAuthors=" + bookAuthors + ", id=" + id + ", title=" + title + "]";
	        }
	    }

	    private static void testCRUDOperations() {

	        CatalogItem item = new CatalogItem();
	        item.setId(601);
	        item.setTitle("Book 601");
	        item.setISBN("611-1111111111");
	        item.setBookAuthors(new HashSet<String>(Arrays.asList("Author1", "Author2")));

	        // Save the item (book).
	        DynamoDBMapper mapper = new DynamoDBMapper(client);
	        mapper.save(item);
	       
	        // Retrieve the item.
	        CatalogItem item1 = mapper.load(CatalogItem.class, 601);
	        System.out.println("Retrieved Item : "+item1);
	        
	        // Update the item.
	        item1.setTitle("Core Java");
	        item1.setBookAuthors(new HashSet<String>(Arrays.asList("Author3", "Author4")));
	        
	        mapper.save(item1);
	        CatalogItem item2 = mapper.load(CatalogItem.class, 601);
	        System.out.println("Updated Item : "+item2);
	        
	        // Retrieve the updated item.
	        DynamoDBMapperConfig config = DynamoDBMapperConfig.builder()
	        		.withConsistentReads(DynamoDBMapperConfig.ConsistentReads.CONSISTENT)
	        		.build();
	        CatalogItem updatedItem = mapper.load(CatalogItem.class, 601, config);
	        System.out.println("Updated Item : "+updatedItem);
	        

	        // Delete the item.
	        //mapper.delete(updatedItem);
	        
	        // Try to retrieve deleted item.
		/*
		 * CatalogItem deletedItem = mapper.load(CatalogItem.class, updatedItem.getId(),
		 * config); if(deletedItem == null)
		 * System.out.println("Item deleted successfully");
		 */
	        
	        
	    }

}
