package com.code_samples;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class RetriveNodeFromXmlString {
	
	
	public void getNode() throws ParserConfigurationException, IOException, SAXException {
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource src = new InputSource();
		src.setCharacterStream(new StringReader(getXmlContent()));
		
		Document doc = builder.parse(src);
		NodeList nodeList = doc.getElementsByTagName("VOUCHER");
		String reference = doc.getElementsByTagName("LOCATION").item(0).getTextContent();
		System.out.println(reference);
		System.out.println(nodeList.getLength());
		
		    System.out.println(nodeList.item(1).getAttributes().getNamedItem("REFERENCE").getNodeValue());
		

		System.out.println(reference);
	}
	
	public String getXmlContent() throws IOException {
		
		File xmlFile = new File( "C:/_Copied from P drive/Shubham/AWS/CodeSamples/src/main/java/voucher.xml");
		Reader fileReader = new FileReader(xmlFile);
		BufferedReader bufReader = new BufferedReader(fileReader);
		StringBuilder sb = new StringBuilder();
		String line = bufReader.readLine();
		while (line != null) {
			sb.append(line);
			line = bufReader.readLine();
		}
		return sb.toString();
	}

	public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException {
		RetriveNodeFromXmlString node = new RetriveNodeFromXmlString();
		node.getNode();
	}
}
