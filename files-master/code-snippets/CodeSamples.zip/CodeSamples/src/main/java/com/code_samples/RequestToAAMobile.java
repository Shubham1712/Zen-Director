package com.code_samples;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class RequestToAAMobile {
	
	public static void main(String[] args) throws IOException {
		
		RetriveNodeFromXmlString node = new RetriveNodeFromXmlString();
		String request = node.getXmlContent();
		String urlParmeters = "xml="+request;

		//URL url = new URL("http://localhost:8080/v1/benefits/");
		URL url = new URL("https://wss-uat.theaa.com/mobile/redeem.ashx");
		byte[] b = urlParmeters.getBytes("UTF-8");
		
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();

		// Set timeout as per needs
		connection.setConnectTimeout(20000);
		connection.setReadTimeout(20000);

		// Set DoOutput to true if you want to use URLConnection for output.
		// Default is false
		connection.setDoOutput(true);
		connection.setDoInput(true);
		connection.setRequestMethod("POST");

		// Set Headers
		connection.setRequestProperty("Accept", "application/xml");
		connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		connection.setRequestProperty( "charset", "utf-8");
		connection.setRequestProperty( "Content-Length", Integer.toString(b.length));
		connection.setUseCaches( false );
		// Write XML
		OutputStream outputStream = connection.getOutputStream();
		
		outputStream.write(b);
		System.out.println(outputStream.toString());
		outputStream.flush();
		outputStream.close();

		// Read XML
		
		
		StringBuffer response = null;
		InputStream inputStream = null;
		try {
			 BufferedReader in = new BufferedReader(new InputStreamReader(
			            connection.getInputStream()));
			        String inputLine;
			         response = new StringBuffer();
			        while ((inputLine = in.readLine()) != null) {
			            response.append(inputLine);
			        } in .close();
			        // print result
			        System.out.println(response.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		 
		
		/*
		 * int result = connection.getResponseCode(); String status =
		 * connection.getResponseMessage(); System.out.println(result+"    "+status);
		 */
		 
		 connection.disconnect();
		 System.out.println(HttpURLConnection.HTTP_BAD_REQUEST);
	}
}
