package com.code_samples;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import reactor.core.publisher.Mono;

public class JsonReader {

	public Mono<ParkingSpace> readData() throws FileNotFoundException, IOException, ParseException{
		
		
		  JSONParser parser = new JSONParser(); 
		  JSONArray arr = (JSONArray) parser.parse(new FileReader("src/main/java/sample.txt")); 
		  ParkingSpace space = new ParkingSpace();
		  for (Object obj : arr) { JSONObject jsonObject = (JSONObject) obj;
		  Long price = (Long) jsonObject.get("price"); //System.out.println(price);
		  String availableDate = (String) jsonObject.get("availableDate");
		  //System.out.println(availableDate);
		  String carParkType = (String) jsonObject.get("carParkType");
		  //System.out.println(carParkType);
		  
		  space.setPrice(price); space.setCarParkType(carParkType);
		  
		  } 
		  System.out.println(space); return Mono.just(space).log();
		 
		 return Mono.fromFuture(client.getItem(request)).map(GetItemResponse::item).map(map -> map.get("JSON").s())
	                .map(json -> {
	                    try {
	                        return objectMapper.readValue(json, PersonVO.class);
	                    } catch (IOException e) {
	                        LOGGER.error("Failed to convert json to object", e);
	                        throw new RuntimeException(e);
	                    }
	                }).onErrorResume(error -> {

	 

	                    return Mono.empty();
	                });
		 
	}
	public static void main(String[] args) throws ParseException, IOException {
		
		JsonReader reader = new JsonReader();
		System.out.println(reader.readData());
		
	}

}
