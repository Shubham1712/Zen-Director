package com.code_samples;

class A {
	
	int  i;
	
	public A() {
		System.out.println("In Class A Contructor");
	}
	
	public void test() {
		System.out.println("In class A");
	}
	
}

class B extends A{
		
	public B() {
		super();
		System.out.println("In class B Constructor");
	}
	public void test1() {
		
		System.out.println("In class B");
		super.test();
	}
	public void test2() {
		this.test();
	}
	
}


public class Test{
	
	public static void main(String[] args) {
		A a = new B();
		a.test();
		
	}
}