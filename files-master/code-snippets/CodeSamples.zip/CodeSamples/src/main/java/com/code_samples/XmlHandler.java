package com.code_samples;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


public class XmlHandler {
	
	public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    //API to obtain DOM Document instance
	    DocumentBuilder builder = null;
	    JAXBContext jaxbContext;
    	Employee emp=null;
    	String json = null;
    	Document xmlDocument = null;
    	
		File file = new File("src/main/java/employee.xml");
		 
		
		try {
			jaxbContext = JAXBContext.newInstance(Employee.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
			emp = (Employee) jaxbUnmarshaller.unmarshal(file);
			
			XmlMapper xmlMapper = new XmlMapper();
			Employee poppy = xmlMapper.readValue(file, Employee.class);
			
			ObjectMapper mapper = new ObjectMapper();
			json = mapper.writeValueAsString(poppy);
			
			builder = factory.newDocumentBuilder();
	         
	        //Parse the content to Document object
	        xmlDocument = builder.parse(file);
			
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
        
		System.out.println(xmlDocument.toString());
		System.out.println(emp);
		System.out.println(json);
	}
}
