package com.code_samples;

import java.util.HashMap;
import java.util.Map;

public class Test1 {

	private String name;
	private int rollno;
	static private Map hash = new HashMap<Test1, Integer>();
	
	public Test1(String name, int rollno) {
		super();
		this.name = name;
		this.rollno = rollno;
	}

	public static void main(String[] args) {
		
		Test1 t1 = new Test1("shubham",101);
		Test1 t2 = new Test1("shubham",101);
		hash.put(t1, 1);
		hash.put(t2, 2);
		
		
		System.out.println(hash.size());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + rollno;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Test1 other = (Test1) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (rollno != other.rollno)
			return false;
		return true;
	}
	
	

}
