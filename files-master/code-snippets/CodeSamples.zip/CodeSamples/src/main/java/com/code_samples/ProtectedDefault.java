package com.code_samples;


class Tea{

	public void test() {
		
		ProtectedDefault pd = new ProtectedDefault();
		System.out.println(pd.a+"	"+pd.b);
	}
	
}



public class ProtectedDefault {
	
	protected int a=10;
	int b=1;
	
	 public static void main(String[] args) {
		
		 Tea t = new Tea();
		 t.test();
		}
}