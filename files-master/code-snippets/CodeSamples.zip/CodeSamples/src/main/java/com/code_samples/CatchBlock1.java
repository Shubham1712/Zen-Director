package com.code_samples;

import java.io.FileNotFoundException;
import java.io.IOException;

public class CatchBlock1 {

	
	{
		try {
					throw new IOException();
		}catch(FileNotFoundException fnfe) {

		} 
		catch(IOException ioe) {

		} 
	} 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
