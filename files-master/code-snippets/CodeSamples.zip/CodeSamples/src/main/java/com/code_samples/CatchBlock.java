package com.code_samples;

import java.io.FileNotFoundException;
import java.io.IOException;

class AOB {
Object test(int a) throws IOException {
return null;
}
}

class BOA extends AOB{
protected String test(int b) throws FileNotFoundException {
return null;
}
} 

class AB{
public Object test(int a) throws IOException {}
}

class B extends AB{
public String test(int b) throws FileNotFoundException {
}
} 

public class CatchBlock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
