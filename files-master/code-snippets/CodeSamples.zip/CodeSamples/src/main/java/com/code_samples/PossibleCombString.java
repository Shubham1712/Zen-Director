package com.code_samples;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class PossibleCombString {
		
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		String str="";
        List<String>  result = new ArrayList<String>();
		 
		System.out.println("Enter string array : ");
		str = scan.nextLine();
		
		if(str.length()!=0) {
			str = str.replaceAll("[,;\\s]", "");
			result = PossibleCombString.allPossibleCombinations(str);
			Collections.sort(result);
		}
		System.out.println(result.toString());
	}
	
	public static List<String> allPossibleCombinations(String s) {
		int mask = 1;
		int length = s.length();
		 List<String> output = new ArrayList<String>();
		while (mask < 1<<length) {
			String interm =  "";
			for (int i = 0; i < length; i++) {
				if (((mask >> i) & 1) != 0) {
					interm += s.charAt(i);
				}
			}
			output.add(interm);
			mask++;
		}
		return output;
	}
}
