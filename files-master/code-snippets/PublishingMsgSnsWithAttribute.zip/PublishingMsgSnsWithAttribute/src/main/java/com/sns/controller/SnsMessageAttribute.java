package com.sns.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.amazonaws.services.sns.model.MessageAttributeValue;

@Component
public class SnsMessageAttribute {
	
	private String message;
	private Map<String, MessageAttributeValue> messageAttributes;
	
	public SnsMessageAttribute(String message) {
		this.message = message;
		this.messageAttributes = new HashMap<String, MessageAttributeValue>();
	}
	
	public SnsMessageAttribute() {
		// TODO Auto-generated constructor stub
	}

	public String getMessage() {
		return message;
	}
	
	public void setMessage(final String message) {
		this.message = message;
	}
	
	
	public void addAttribute(final String attributeName, final String attributeValue) {
		final MessageAttributeValue messageAttributeValue = new MessageAttributeValue()
				.withDataType("String")
				.withStringValue(attributeValue);
		messageAttributes.put(attributeName, messageAttributeValue);
	}
	
	public void addAttribute(final String attributeName, final Number attributeValue) {
		final MessageAttributeValue messageAttributeValue = new MessageAttributeValue()
				.withDataType("Number")
				.withStringValue(attributeValue.toString());
		messageAttributes.put(attributeName, messageAttributeValue);
	}
	
	public void addAttribute(final String attributeName, final ArrayList<?> attributeValues) {
		
		String value, delimeter = ",", prefix = "[", suffix="]";
		
		if(attributeValues.get(0).getClass() == String.class) {
			delimeter = "\",\""; //""
			prefix = "[\""; 	 //"["	
			suffix = "\"]";		 //"]"
		}
		
		value = attributeValues
				.stream()
				.map(Object::toString)
				.collect(Collectors.joining(delimeter,prefix,suffix));
		final MessageAttributeValue messageAttributeValue = new MessageAttributeValue()
                .withDataType("String.Array")
                .withStringValue(value);
        messageAttributes.put(attributeName, messageAttributeValue);
	}
	
	public String publish(final AmazonSNS snsClient,final String topicArn) {
			
		final PublishRequest request = new PublishRequest(topicArn, message)
				.withMessageAttributes(messageAttributes);
		final PublishResult result = snsClient.publish(request);
		
		return result.getMessageId();
	}
}















