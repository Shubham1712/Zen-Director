package com.sns;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;

@Configuration
public class SnsConfig {

		
	@Value("${cloud.aws.credentials.access-key}")
	private String awsId;
	
	@Value("${cloud.aws.credentials.secret-key}")
	private String awsKey;
	
	@Bean
	public AmazonSNS snsClient() {
		return AmazonSNSClientBuilder.standard().withRegion(Regions.US_EAST_1)
				.withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(awsId,awsKey)))
				.build();
	}
	
	
}



















