package com.sns.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.services.sns.AmazonSNS;
import com.sns.SnsConfig;


@RestController
@RequestMapping("/sns")
public class SnsController {
	
	@Autowired
	private SnsMessageAttribute message;
	
	@Autowired
	private SnsConfig config;
	
	@Autowired
	private AmazonSNS snsClient;
	
	private String topicArn ="arn:aws:sns:us-east-1:854098562793:voucher";
	
	@RequestMapping("/attribute")
	public String addAttribute() throws IOException {
		
		message = new SnsMessageAttribute(getXmlContent());
		
		message.addAttribute("store", "example_corp");
		message.addAttribute("event", "order_placed");
		
		final ArrayList<String> interestsValues = new ArrayList<String>();
		interestsValues.add("soccer");
		interestsValues.add("rugby");
		interestsValues.add("hockey");
		message.addAttribute("customer_interests", interestsValues);
		
		message.addAttribute("price_usd", 1000);
		
		return "Attribute added";
	}
	
	private String getXmlContent() throws IOException {
		File xmlFile = new File( "C:/_Copied from P drive/Shubham/AWS/PublishingMsgSnsWithAttribute/src/main/resources/voucher.xml");
		Reader fileReader = new FileReader(xmlFile);
		BufferedReader bufReader = new BufferedReader(fileReader);
		StringBuilder sb = new StringBuilder();
		String line = bufReader.readLine();
		while (line != null) {
			sb.append(line);
			line = bufReader.readLine();
		}
		return sb.toString();
	}

	@RequestMapping("/publish")
	public String publish() {
		
		snsClient = config.snsClient();
		String msgId = message.publish(snsClient, topicArn);
		return "Published with msgId - "+msgId;
		
	} 
}
